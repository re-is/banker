// HUF tagolás:
String.prototype.toAmount = (function() { return String(this).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') });
Number.prototype.toAmount = (function() { return String(this).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') });

// Szóközök törlése:
String.prototype.fromAmount = (function() { let t = String(this); return parseInt(((t === '') ? '0' : t).replace(/\s/g, '')) });

// 1 -> 01:
// noinspection JSUnusedGlobalSymbols
String.prototype.toDouble = (function() { return ('0' + this).slice(-2) });
Number.prototype.toDouble = (function() { return ('0' + String(this)).slice(-2) });

// Hónap nevek:
Number.prototype.monthName = (function() {
	let t = Number(this);
	return ((t === 0) ? ' Január' : (t === 1) ? ' Február' : (t === 2) ? ' Március' : (t === 3) ? ' Április' : (t === 4) ? ' Május' : (t === 5) ? ' Június' : (t === 6) ? ' Július' : (t === 7) ? ' Augusztus' : (t === 8) ? ' Szeptember' : (t === 9) ? ' Október' : (t === 10) ? ' November' : ' December');
});

// Toast & Log:
function psh(t) { // noinspection JSUnresolvedVariable, JSUnresolvedFunction
	g.isPhone ? ad.msg(t) : console.log(t)
}

// Gombok száma:
// noinspection JSUnusedGlobalSymbols
function buttons() { psh(Array.from(document.getElementsByClassName('buttons')).length) }

// Funkció futtatása 100ms múlva, csak egyszer:
function oneTimer(id, func, ms) { if (!g.timers[id]) g.timers[id] = setTimeout(function() { func(); delete g.timers[id] }, (ms ? ms : 100)) }

// Teljesítmény:
// noinspection JSUnusedGlobalSymbols
function power() {
	let ms = new Date().getTime(), t;
	if (g.power === 0) return g.power = ms;
	t = (ms - g.power);
	g.power = 0;
	psh(t);
	return t;
}

// NumPad láthatóság:
function showNumPad(b) {
	// Megjelenítés onBlur() :
	if (b) setTimeout(function() { g.class.elem('numpad').style.display = 'table' }, 200);
	// Elrejtés onFocus() :
	else g.class.elem('numpad').style.display = 'none';
}

// Oldal láthatóság:
function showPage(cl_ss) {
	const divs = document.getElementsByTagName('div');
	for (let div of divs) { if (g.class.get(div, 'Page')) g.class.set(div, 'visible', false) }
	g.class.set(cl_ss, 'visible', true);
}

// CSS property lekérése:
function getCssValue(styleObject) {
	let selectors = '', styleArray;
	for (let selector in styleObject) selectors += (' ' + selector);
	let rules = document.styleSheets[0].cssRules, value = [];
	for (let rule of rules) {
		// Ha van ilyen selector:
		if (selectors.indexOf(rule.selectorText) > -1) {
			styleArray = styleObject[rule.selectorText];
			for (let i in styleArray) { // noinspection JSUnfilteredForInLoop
				value.push(rule.cssText.split(styleArray[i] + ': ')[1].split(';')[0]);
			}
		}
	}
	return value;
}

// CSS property megadása:
function setCssValue(styleObject) {
	let selectors = '', styleArray, decl;
	for (let selector in styleObject) selectors += (' ' + selector);
	let rules = document.styleSheets[0].cssRules;
	for (let rule of rules) {
		// Ha van ilyen selector:
		if (selectors.indexOf(rule.selectorText) > -1) {
			styleArray = styleObject[rule.selectorText];
			// Stílus darabolása:
			for (let i in styleArray) {
				// noinspection JSUnfilteredForInLoop
				decl = styleArray[i].split(': ');
				rule.style[decl[0]] = decl[1];
			}
		}
	}
}

package com.example.banker

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.RemoteViews
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import java.io.File
import kotlin.system.exitProcess

object GL {
    lateinit var context: Context
    lateinit var webView: WebView
    lateinit var nLayout: RemoteViews
    lateinit var lightMr: SensorManager
    lateinit var notifMr: NotificationManager
    lateinit var channel: NotificationChannel
    lateinit var builder: NotificationCompat.Builder
    lateinit var txtFile: File
    lateinit var lSensor: Sensor
    var lightValue = 0
    var managerId = 662813244
    var channelId = "Banker"
    var channelNm = "Banker 1.0"
    var packageNm = "com.example.banker"
    var developer = true
}

class JsInterface {

    @JavascriptInterface
    fun msg(text: String) {
        Toast.makeText(GL.context, text, "3".toInt()).show()
    }

    @JavascriptInterface
    fun setData(text: String) {
        GL.txtFile.writeText(text)
    }

    @JavascriptInterface
    fun getData(): String {
        return GL.txtFile.readText()
    }

    @JavascriptInterface
    fun isDark(): Boolean {
        return (GL.context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES)
    }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun notificationBar(show: Boolean, dark: Boolean, balance: String, info: String, amount: String) {
        if (show) {
            // Dark mode:
            if (dark) {
                GL.nLayout = RemoteViews(GL.packageNm, R.layout.dark_notification)
                GL.nLayout.setTextViewText(R.id.dark_balance, balance)
                GL.nLayout.setTextViewText(R.id.dark_info, info)
                GL.nLayout.setTextViewText(R.id.dark_info_amount, amount)
            }
            // Light:
            else {
                GL.nLayout = RemoteViews(GL.packageNm, R.layout.light_notification)
                GL.nLayout.setTextViewText(R.id.light_balance, balance)
                GL.nLayout.setTextViewText(R.id.light_info, info)
                GL.nLayout.setTextViewText(R.id.light_info_amount, amount)
            }

            // Notification Channel, Oreo+ :
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                GL.channel = NotificationChannel(GL.channelId, GL.channelNm, NotificationManager.IMPORTANCE_LOW)
                GL.channel.enableLights(true)
                GL.channel.enableVibration(false)
                GL.channel.setShowBadge(false)
                GL.notifMr.createNotificationChannel(GL.channel)
                GL.builder = NotificationCompat.Builder(GL.context, GL.channelId)
            } else {
                GL.builder = NotificationCompat.Builder(GL.context)
            }

            // Create an Intent for the MainActivity:
            val mIntent = Intent(GL.context, MainActivity::class.java)
            // Create the TaskStackBuilder:
            val mPendingIntent: PendingIntent? = TaskStackBuilder.create(GL.context).run {
                // Add the intent, which inflates the back stack:
                addNextIntentWithParentStack(mIntent)
                // Get the PendingIntent containing the entire back stack:
                getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
            }

            // Notification Builder:
            GL.builder.priority = NotificationCompat.PRIORITY_LOW
            GL.builder.setCategory(NotificationCompat.CATEGORY_MESSAGE)
            GL.builder.setVisibility(NotificationCompat.VISIBILITY_SECRET)
            GL.builder.setSmallIcon(R.mipmap.icon_statusbar)
            GL.builder.setCustomContentView(GL.nLayout)
            GL.builder.setContentIntent(mPendingIntent)
            GL.builder.setOngoing(true)
            GL.notifMr.notify(GL.managerId, GL.builder.build())
        }
        else {
            GL.notifMr.cancel(GL.managerId)
        }
    }

    @JavascriptInterface
    fun reloadApp() {
        val i = Intent(GL.context, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        GL.context.startActivity(i)
    }

    @JavascriptInterface
    fun minimizeApp() {
        val i = Intent()
        i.action = Intent.ACTION_MAIN
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        i.addCategory(Intent.CATEGORY_HOME)
        GL.context.startActivity(i)
    }

    @JavascriptInterface
    fun closeApp() {
        exitProcess(-1)
    }

    @JavascriptInterface
    fun lightSensorValue(): Int {
        return GL.lightValue
    }

}

class LightInterface : SensorEventListener {

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    override fun onSensorChanged(event: SensorEvent) { GL.lightValue = event.values[0].toInt() }

}

class MainActivity : AppCompatActivity() {

    // OnCreate:
    @SuppressLint("SetJavaScriptEnabled")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Internal Storage/Android/data/com.example.banker/files
        val bankerFiles = this.getExternalFilesDir(null)?.absolutePath

        // Set context and manager:
        GL.context = this
        GL.notifMr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Set light manager:
        GL.lightMr = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        GL.lSensor = GL.lightMr.getDefaultSensor(Sensor.TYPE_LIGHT)

        // Set up Backup text file and create if it does not exist:
        GL.txtFile = File("${bankerFiles}/Banker-Adatok.txt")
        if (!GL.txtFile.exists()) GL.txtFile.createNewFile()

        // Create WebView:
        GL.webView = findViewById(R.id.wV)
        val set: WebSettings = GL.webView.settings
        set.textZoom = 100
        set.javaScriptEnabled = true
        set.allowFileAccess = true
        GL.webView.setBackgroundColor(Color.TRANSPARENT)
        GL.webView.addJavascriptInterface(JsInterface(), "ad")

        // Developer mode:
        val iHtml = File("${bankerFiles}/index.html")
        if (GL.developer && iHtml.exists()) {
            GL.webView.loadUrl("file:///${iHtml}")
        } else {
            GL.webView.loadUrl("file:///android_asset/index.html")
        }

    }

    override fun onBackPressed() { GL.webView.loadUrl("javascript:onBackButton();") }

    override fun onResume() {
        super.onResume()
        GL.lightMr.registerListener(LightInterface(), GL.lSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        GL.lightMr.unregisterListener(LightInterface())
    }

}
